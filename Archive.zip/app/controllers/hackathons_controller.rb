class HackathonsController < ApplicationController
    def show
    end
end
