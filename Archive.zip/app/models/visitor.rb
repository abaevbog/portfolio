class Visitor < ActiveRecord::Base
  end
  