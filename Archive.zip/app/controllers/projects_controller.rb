class ProjectsController < ApplicationController
    def show
    end
    
end
