class MessagesController < ApplicationController
    def show
        @messages = Message.all
    end
end
